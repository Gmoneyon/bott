import config  
import websocket 
import numpy, talib
from binance.client import Client  
from binance.enums import *  
import json
import random

  
client = Client(config.API_KEY, config.API_SECRET)  

SOCKET = "wss://stream.binance.com:9443/ws/dogeusdt@kline_15m" 
 
def on_open(ws): 
    print('|INICIADO!|') 
def on_close(ws): 
    print('closed connection') 
def on_message(ws, message): 
     
    json_message = json.loads(message)  
     
    candles = json_message['k'] 
 
    frames = float(candles['o']) 
    print("________________________________") 
    print("FECHOU EM:",frames,"USDT") 
    frames_b = (candles['h']) 
    print("PREÇO MÁXIMO:",frames_b,"USDT") 
    frames_c = (candles['l']) 
    print("PREÇO MINIMO:",frames_c,"USDT") 
    frames_d = float(candles['c']) 
    print("PREÇO ATUAL",frames_d,"USDT") 
    print("________________________________")
    

    candles_b = client.get_klines(symbol='DOGEUSDT', interval=Client.KLINE_INTERVAL_15MINUTE)
    
    #preço de abertura, maxima, minima, fechamento
    select_price_b = candles_b[-2]
    select_price_c = candles_b[-3]
    select_price_d = candles_b[-4]
    select_price_e = candles_b[-5]
    select_price_f = candles_b[-6]
    select_price_g = candles_b[-7]
    select_price_h = candles_b[-8]
    select_price_i = candles_b[-9]
    select_price_j = candles_b[-10]
    select_price_l = candles_b[-11]
    select_price_k = candles_b[-12]
    select_price_m = candles_b[-13]
    select_price_m2 = candles_b[-14]
    select_price_m3 = candles_b[-15]
    select_price_m4 = candles_b[-16]
    select_price_m5 = candles_b[-17]
    select_price_m6 = candles_b[-18]
    select_price_m7 = candles_b[-19]
    select_price_m8 = candles_b[-20]
    select_price_m9 = candles_b[-21]
    select_price_m10 = candles_b[-22]
    select_price_m11 = candles_b[-23]
    select_price_m12 = candles_b[-24]
    select_price_m13 = candles_b[-25]
    
    #comparar
    #print('ULT. FECHOU:',select_price_b)
    
    #seleçãoultimosfechamentos
    px = select_price_b[4]
    px_b = select_price_c[4]
    px_c = select_price_d[4]
    px_d = select_price_e[4]
    px_e = select_price_f[4]
    px_f = select_price_g[4]
    px_g = select_price_h[4]
    px_h = select_price_i[4]
    px_i = select_price_j[4]
    px_j = select_price_l[4]
    px_l = select_price_k[4]
    px_k = select_price_m[4]
    px_2 = select_price_m2[4]
    px_3 = select_price_m3[4]
    px_4 = select_price_m4[4]
    px_5 = select_price_m5[4]
    px_6 = select_price_m6[4]
    px_7 = select_price_m7[4]
    px_8 = select_price_m8[4]
    px_9 = select_price_m9[4]
    px_10 = select_price_m10[4]
    px_11 = select_price_m11[4]
    px_12 = select_price_m12[4]
    px_13 = select_price_m13[4]
 
    candles_period = [1,2,3,4,5,6,7,8,9,10,11,12]
    
    candles_period_2 = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]
   
    add_candles = candles_period[0]=px
    add_candles_b = candles_period[1]=px_b
    add_candles_c = candles_period[2]=px_c
    add_candles_d = candles_period[3]=px_d
    add_candles_e = candles_period[4]=px_e
    add_candles_f = candles_period[5]=px_f
    add_candles_g = candles_period[6]=px_g
    add_candles_h = candles_period[7]=px_h
    add_candles_i = candles_period[8]=px_i
    add_candles_j = candles_period[9]=px_j
    add_candles_l = candles_period[10]=px_l
    add_candles_k = candles_period[11]=px_k
    
    add_candles = candles_period_2[0]=px
    add_candles_b = candles_period_2[1]=px_b
    add_candles_c = candles_period_2[2]=px_c
    add_candles_d = candles_period_2[3]=px_d
    add_candles_e = candles_period_2[4]=px_e
    add_candles_f = candles_period_2[5]=px_f
    add_candles_g = candles_period_2[6]=px_g
    add_candles_h = candles_period_2[7]=px_h
    add_candles_i = candles_period_2[8]=px_i
    add_candles_j = candles_period_2[9]=px_j
    add_candles_l = candles_period_2[10]=px_l
    add_candles_k = candles_period_2[11]=px_k
    add_candles_k = candles_period_2[12]=px_2
    add_candles_k = candles_period_2[13]=px_3
    add_candles_k = candles_period_2[14]=px_4
    add_candles_k = candles_period_2[15]=px_5
    add_candles_k = candles_period_2[16]=px_6
    add_candles_k = candles_period_2[17]=px_7
    add_candles_k = candles_period_2[18]=px_8
    add_candles_k = candles_period_2[19]=px_9
    add_candles_k = candles_period_2[20]=px_10
    add_candles_k = candles_period_2[21]=px_11
    add_candles_k = candles_period_2[22]=px_12
    add_candles_k = candles_period_2[23]=px_13
    
    np = candles_period
    #print('Ultimos 12 fechamentos',np)
    float_np = list(numpy.array(np, dtype='float'))
    lst_np = numpy.array(float_np)
    soma = sum(lst_np)
    print('soma',soma)
    result_sm = soma/12
    #print('MÉDIA 12p:',result_sm)
    #---------#
    
    np_2 = candles_period_2
    #print('Ultimos 24 fechamentos',np_2)
    float_np_2 = list(numpy.array(np_2, dtype='float'))
    lst_np_2 = numpy.array(float_np_2)
    soma_2  = sum(lst_np_2)
    print('soma',soma_2)
    result_sm_2 = soma_2/24
    #print('MÉDIA 24p:',result_sm_2)
    
    #Intificadordeltaoultb
    media12 = result_sm
    media12_rd = round (media12, 5)
    print('Média_12:',media12_rd)
    media24 = result_sm_2
    media24_rd = round (media24, 5)
    print('Média_24:',media24_rd)
    
    saldo_doge = client.get_asset_balance(asset='DOGE')
    dogesaldo = float(saldo_doge["free"])
    saldo_doge_b = round(dogesaldo, 0)
    print('saldo doge:',saldo_doge_b)
    
    sd_1 = 200.0
    sd_2 = saldo_doge_b
    
    trades = client.get_my_trades(symbol='DOGEUSDT')
    price_buy = (trades[-1])
    price_buy_b = float(price_buy['price'])
    sprice = price_buy_b
    rd_a = round (sprice, 4)  
    sm = sprice * 0.01  
    sm_2 = sm + sprice  
    rd = round (sm_2, 4)  
    price_sell = rd 
    print('PREÇO DE VENDA',price_sell)
    qtdoge = saldo_doge_b - 1.0
    
   
    if sd_2 > sd_1:
        	 
             order = client.order_limit_sell(
             symbol='DOGEUSDT',
             quantity=qtdoge,
             price=price_sell)
             print('SALDO DISPONÍVEL...')
             print('ORDEM DE VENDA CRIADO!')
             
    else:
        	 print('SALDO INSUFICIENTE!')
        	     
    if media12_rd > media24_rd:
       saldo_usdt = client.get_asset_balance(asset='USDT')
       susdt = float(saldo_usdt["free"])
       saldo_usdt_b = round(susdt, 2)
       df_saldo = saldo_usdt_b / frames_d
       df_saldo_rd = round(df_saldo, 0)
       print("quanty:",df_saldo_rd)
       qtdoge_2 = df_saldo_rd  - 1.0
       pulback_media12 = round(media12, 5)

       order = client.order_limit_buy(
       symbol='DOGEUSDT',
       quantity=qtdoge_2,
       price=pulback_media12)
       print('LTA: ALTA')
       print('ORDEM DE COMPRA CRIADO!')
        
    else:
        	 print('EM TENDÊNCIA DE BAIXA')

        	
ws = websocket.WebSocketApp(SOCKET, on_open=on_open, on_close=on_close, on_message=on_message) 
ws.run_forever()