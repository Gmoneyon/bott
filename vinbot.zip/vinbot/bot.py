import requests
import websocket, json, pprint, talib, numpy
import config
from binance.client import Client
from binance.enums import *

SOCKET = "wss://stream.binance.com:9443/ws/ethusdt@kline_1m"

RSI_PERIOD = 14
RSI_OVERBOUGHT = 70
RSI_OVERSOLD = 30
TRADE_SYMBOL = 'ETHUSDT'
TRADE_QUANTITY = 0.005

closes = []
in_position = False

client = Client(config.API_KEY, config.API_SECRET)

def order(side, quantity, symbol, order_type=ORDER_TYPE_MARKET):

    try:

       print("sending order")
       order = client.create_order(symbol=symbol, side=side, type=order_type, quantity=quantity)
       print(order)
       
    except Exception as e:
       print("an exception occured - {}".format(e))

       return False

    return True


def on_open(ws):
    print ('opened conection')

def on_close(ws):
    print ('closed conection')

def on_message(ws, message):
    global closes, in_position

    print ('menssage received')
    json_message = json.loads(message)
    pprint.pprint(json_message)

    candle = json_message['k']

    is_candle_closed = candle['c']

    close = candle['o']

    if is_candle_closed!=candle:
        print("candle closed at {}".format(close))
        closes.append(float(close))                      
        print("closes")
        print(closes)

        if len(closes) > RSI_PERIOD:
            np_closes = numpy.array(closes)
            rsi = talib.RSI(np_closes, RSI_PERIOD)
            print("all rsi calculated so far")
            print(rsi)
            last_rsi = rsi[-1]
            print("the current is {}".format(last_rsi))

            if last_rsi > RSI_OVERBOUGHT:
                if in_position:


                   print("SOBRE-COMPRADO! sell! sell! sell!")
                   order_succeeded = order(SIDE_SELL, TRADE_QUANTITY, TRADE_SYMBOL)
                   if order_succeeded:
                       in_position=False
                
                else:
                    print("preço abaixo da sobre-compra")


            if last_rsi < RSI_OVERSOLD:
                if in_position:
                    print("preço acima da sobre-venda")

                else:
                    print("SOBRE-VENDIDO! buy! buy! buy!")

                    order_succeeded = order(SIDE_BUY, TRADE_QUANTITY, TRADE_SYMBOL)
                    if order_succeeded:
                        in_position=True
                


ws = websocket.WebSocketApp(SOCKET, on_open=on_open, on_close=on_close, on_message=on_message)


ws.run_forever()